# gitlab-settings-manager
Easily manage gitlab project configuration and settings using gitlab-project-cfg.yml


